package com.srp.qa.tests;

import org.testng.annotations.Test;
import com.srp.qa.utillity.ConfigReader;
import com.srp.qa.utillity.Srp_utillity;
import com.srp.qa.utillity.TestUtil;
import org.testng.annotations.BeforeMethod;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;

public class SrpInquiryFormtest extends Srp_utillity{
	  
	
	
	 
	  @BeforeMethod
	  public void setup(ITestResult result) throws Throwable {
		 
		 testHeader(result.getMethod().getMethodName());
		 ConfigReader config = new ConfigReader();
		 System.setProperty("webdriver.chrome.driver", config.getChromePath());
		 driver=new ChromeDriver();
		 driver.get(config.appUrl());
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 
	  }
	  
	  @DataProvider
	  public Iterator<Object[]> getData(){
		  ArrayList<Object[]> testdata = TestUtil.getDataFromExcel();
		  return testdata.iterator();
	  }
	
	  
	  @Test(dataProvider = "getData")
	  public void enterformData(String username, String password, String Retain_Owner, String First_Name, String Last_Name, String  Campus, String  Program,
			  String  Specialization, String  Interested_Timeframe, String Gender, String Email, String  Home_Phone,
			  String  Mobile_Phone, String  Street_Address, String  City, String State, String  Zip, String  Campaign) throws Throwable{

		  // tO FILL THE iNQUIRY FORM
		  enter_inquiryForm(username, password, Retain_Owner, First_Name, Last_Name, Campus, Program, Specialization, Interested_Timeframe, Gender, Email, Home_Phone, Mobile_Phone, Street_Address, City, State, Zip, Campaign);
		
		  
	  }
	  


	@AfterMethod
	  public void tearDown() throws Exception {
		  
		  driver.quit();
		  createHtmlSummaryReport("Chrome");
		  closeDetailedReport("Chrome");
		  closeSummaryReport("Chrome");
	  }
	
	
	 
}
