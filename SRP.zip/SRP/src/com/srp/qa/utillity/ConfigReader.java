package com.srp.qa.utillity;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {
	
	Properties prop;
	
	public ConfigReader()  {
		try {
			File f = new File("E:\\SRP\\SRP\\src\\com\\srp\\qa\\config\\Config.property");
			FileInputStream finp=new FileInputStream(f);
			prop= new Properties();
			prop.load(finp);
		}
		catch(Exception exp) {
			
		}
	}
	
	public String getChromePath() {
		return prop.getProperty("ChromeDriver");
	}
	public String appUrl() {
		return prop.getProperty("URL");
	}

}
