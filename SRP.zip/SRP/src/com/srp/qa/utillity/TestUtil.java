package com.srp.qa.utillity;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.srp.qa.excel.utillity.Xls_Reader;

public class TestUtil extends HtmlReport{
	public WebDriver driver;
	public static Xls_Reader reader;

	public void TestrUtil() throws Exception {
		//htmlCreateReport();
		//testHeader("Sample");
	}
	
	public void launchApp() {
		System.setProperty("webdriver.chrome.driver", "E:/SRP/SRP/resources/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.get("http://test.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	}
	
	
	public void login() {
		driver.findElement(By.xpath("//*[@name='username']")).sendKeys("Prabhakar");
		driver.findElement(By.xpath("//*[@name='pw']")).sendKeys("8756437");
		driver.findElement(By.xpath("//*[@name='Login']")).click();
	}
	
	public static ArrayList<Object[]> getDataFromExcel(){
		
	     String filename = System.getProperty("user.dir") + File.separator + "Data" + File.separator + "SRP_NewInquiry.xlsx";
		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		try {
			reader = new Xls_Reader(filename);
			
		}
		catch(Exception E) {
			E.printStackTrace();
		}
		/*
		for(int rownum=2; rownum<=reader.getRowCount("SRP");rownum++) {
			String username= reader.getCellData("SRP", "username", rownum);
			String pass= reader.getCellData("SRP", "password", rownum);
			myData.add(new Object[]{username,pass});
		} */
		
		
		for(int rownum=2; rownum<=reader.getRowCount("SRP");rownum++) {
			String username= reader.getCellData("SRP", "username", rownum);
			String pass= reader.getCellData("SRP", "password", rownum);
			String Retain_Owner = reader.getCellData("SRP","Retain Owner",rownum);
			String First_Name = reader.getCellData("SRP","First Name",rownum);
			String Last_Name = reader.getCellData("SRP","Last Name",rownum);
			String  Campus = reader.getCellData("SRP","Campus",rownum);
			String  Program = reader.getCellData("SRP","Program",rownum);
			String  Specialization = reader.getCellData("SRP","Specialization",rownum);
			String  Interested_Timeframe = reader.getCellData("SRP","Interested Timeframe",rownum);
			String Gender = reader.getCellData("SRP","Gender",rownum);
			String Email = reader.getCellData("SRP","Email",rownum);
			String  Home_Phone = reader.getCellData("SRP","Home Phone",rownum);
			String  Mobile_Phone = reader.getCellData("SRP","Mobile Phone", rownum);
			String  Street_Address = reader.getCellData("SRP","Street Address", rownum);
			String  City = reader.getCellData("SRP","City", rownum);
			String  State = reader.getCellData("SRP","State",rownum);
			String  Zip = reader.getCellData("SRP","Zip", rownum);
			String  Campaign = reader.getCellData("SRP","Campaign",rownum);
			
			
			myData.add(new Object[]{username,pass,Retain_Owner, First_Name,Last_Name,Campus, Program, Specialization, Interested_Timeframe,Gender, Email, Home_Phone, Mobile_Phone, Street_Address, City, State, Zip, Campaign});
		}
			
		//myData.add(new Object[]{"username","pass"});
		return myData;
		
	}
	
} 

