package com.srp.qa.utillity;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.srp.qa.excel.utillity.Xls_Reader;

public class Util extends HtmlReport{
	public WebDriver driver;
	public static Xls_Reader reader;

	
	
	public void launchApp() {
		System.setProperty("webdriver.chrome.driver", "E:\\SRP\\SRP\\resources\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.get("http://test.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	}
	
	
	public void login() {
		driver.findElement(By.xpath("//*[@name='username']")).sendKeys("Prabhakar");
		driver.findElement(By.xpath("//*[@name='pw']")).sendKeys("8756437");
		driver.findElement(By.xpath("//*[@name='Login']")).click();
	}
	
	public static ArrayList<Object[]> getDataFromExcel(){
		
		
		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		try {
			reader = new Xls_Reader("E:\\SRP\\SRP\\src\\com\\srp\\qa\\testdata\\SRP_testdata.xlsx");
			
		}
		catch(Exception E) {
			E.printStackTrace();
		}
		
		for(int rownum=2; rownum<=reader.getRowCount("SRP");rownum++) {
			String username= reader.getCellData("SRP", "username", rownum);
			String pass= reader.getCellData("SRP", "password", rownum);
			myData.add(new Object[]{username,pass});
		}
		return myData;
		
	}
	
} 
