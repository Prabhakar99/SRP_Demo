package com.srp.qa.utillity;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Srp_utillity extends ActionEngine {

	public void enter_inquiryForm(String username, String password, String Retain_Owner, String First_Name, String Last_Name, String  Campus, String  Program,
			  String  Specialization, String  Interested_Timeframe, String Gender, String Email, String  Home_Phone,
			  String  Mobile_Phone, String  Street_Address, String  City, String State, String  Zip, String  Campaign) throws Throwable {
		  
		
			By usrname=By.xpath("//*[@name='username']");
			By psw = By.xpath("//*[@name='pw']");
			By login = By.xpath("//*[@name='Login']");
			By show_navigation = By.xpath("//*[@title='Show Navigation Menu']");
			By new_inquiry_btn= By.xpath("//*[@title='SRP New Inquiry Form']");
					  
			By retrain_owner = By.xpath("//*[contains(@name,'opp__retrainowner')]");			
			By firstname = By.xpath("//*[contains(@name,'firstname')]");
			By lastname = By.xpath("//*[contains(@name,'lastname')]");
			By campusPicklist= By.xpath("//*[contains(@id,'campusPicklist')]");
			By programPicklist = By.xpath("//*[contains(@id,'programPicklist')]");
			By specPicklist = By.xpath("//*[contains(@id,'specPicklist')]");
			By timeframe = By.xpath("//*[contains(@name,'timeframe')]");
			By gender = By.xpath("//*[contains(@name,'gender')]");
			By email = By.xpath("//*[contains(@id,'emailAdd')]");
			By homephone = By.xpath("//*[contains(@id,'Home_Phone')]");
			By mobile = By.xpath("//*[contains(@id,'Mobile_Phone')]");
			By address = By.xpath("//*[contains(@id,'Address')]");
			By city = By.xpath("//*[contains(@id,'City')]");
			By state = By.xpath("//td[@class='data2Col ']/*[contains(@id,'State')]");
		//	By country = By.xpath("//*[contains(@id,'Country')]");
			By zip = By.xpath("//*[contains(@id,'Zip')]");
			By campaign = By.xpath("//*[contains(@id,'campaignList')]"); 
			By save_btn = By.xpath("//*[contains(@value,'Save')]");
			By error_msg = By.xpath("//*[contains(@class,'message errorM3')]");
			
			type(usrname, username, "Username");
			type(psw,password,"Password");
			click(login, "Login Button");
			SuccessReport("Verify Homepage", "Successfully Login into the application");
			Thread.sleep(30000);
			click(show_navigation, "Show navigation Option");
			click(new_inquiry_btn, "New Inquiry Option");
			Thread.sleep(2000);
			
		  //WebElement f1 = driver.findElement(By.xpath(//ifra))// iframe[name^='vfFrameId_158402485']
		  
		  List<WebElement> iframes = driver.findElements(By.xpath("//iframe"));
		  
		  System.out.println(iframes.size());

	        // you can reach each frame on your site
	        for (WebElement iframe : iframes) {

		        // switch to every frame
		          driver.switchTo().frame(iframe);
		  		  
		          click(retrain_owner, "Retain_Owner");
		            
		  		  Thread.sleep(3000);
		  		  type(firstname, First_Name, "First Name");
		  		  type(lastname, Last_Name, "Last Name");
		  		  Thread.sleep(2000);
		  		  type(campusPicklist, Campus, "Campus");
				  Thread.sleep(2000);
				  type(programPicklist, Program, "Program");
				  Thread.sleep(2000);
				  type(specPicklist, Specialization, "Specialization");
				  Thread.sleep(2000);
				  type(timeframe, Interested_Timeframe, "Interested_Timeframe");
				  Thread.sleep(2000);
				  type(gender, Gender,"Gender");
				  Thread.sleep(2000);
				  type(email, Email, "Email");
				  type(homephone, Home_Phone, "Home Phone");
				  type(mobile, Mobile_Phone, "Mobile Phone");
				  type(address, Street_Address, "Street_Address");
				  type(city, City, "City");
				  type(state, State, "State");
				  type(zip, Zip, "Zip");
				  type(campaign, Campaign, "Campaign");
				  
				  click(save_btn, "Save Button");
				   
				  				
				  Thread.sleep(3000);
				  
				  boolean form_status = isElementPresentNegative(error_msg, "Error While creating the opportunity");
				  if(form_status==true) {
					  failureReport("Verify the Form Status", "Error While creating the opportunity ");
				  } else {
					  SuccessReport("Verify the Form Status", "Successfully created the opportunity ");
				  }
				  
					/*WebElement gotoopp=  driver.findElement(By.xpath("//a[contains(@onclick,'true')]"));
					if(driver.findElement(By.xpath("//a[contains(@onclick,'true')]")).isDisplayed()==true) {
						 
					}else {
						 
					}*/
			        
				  driver.switchTo().defaultContent();
				  break;
	        }
	    
	}
	
}
