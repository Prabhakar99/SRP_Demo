package com.srp.qa.utillity;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ActionEngine extends TestUtil{

	public WebDriverWait wait;
	boolean b = true;
	
	public boolean click(By locator, String locatorName) throws Throwable {

		ExplicitWaitOnElementToBeClickable(locator);
		boolean flag = false;
		try {
			driver.findElement(locator).click();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (!flag) {
				failureReport("Click", "Unable to click on " + locatorName);
				return true;
			} else if (b && flag) {
				SuccessReport("Click", "Successfully clicked on " + locatorName);

			}
		}
		return flag;
	}
	
	
	public boolean type(By locator, String testdata, String locatorName) throws Throwable {
		ExplicitWaitOnElementToBeClickable(locator);
		boolean flag = false;
		try {
			//driver.findElement(locator).clear();
			Thread.sleep(1000);
			driver.findElement(locator).sendKeys(testdata);
			flag = true;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (!flag) {
				failureReport("Type ",
						"Data typing action is not perform on " + locatorName + " with data is " + testdata.replace(":", ""));
				return true;
			} else if (b && flag) {

				SuccessReport("Type ",
						"Data typing action is performed on " + locatorName + " with data is " + testdata.replace(":", ""));
			}
		}
		return flag;
	}
	
	
	
	public boolean isElementPresent(By by, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			driver.findElement(by);
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (!flag) {
				failureReport("Element Present ", locatorName + " is not present on the page");
			} else if (b && flag) {
				SuccessReport("Element Present ", locatorName+" present on the page");
			}

		}
	}
	
	
	public boolean isElementPresentNegative(By by, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			driver.findElement(by);
			flag = true;
			return flag;
		} catch (Exception e) {
			return flag;

		}
	}
	
	public void ExplicitWaitOnElementToBeClickable(By locator) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
		} catch (Throwable e) {
		}
	}
}
